# Keep OpenCV JNI classes intact for release builds
-keep class org.opencv.** { *; }
-dontwarn org.opencv.**
